import os
for alg in ['alg02_epsilon_constraint.py', 'alg03_benson.py', 'alg14_nsga2.py', 'alg28_motlbo.py', 'alg29_moba.py', 'alg17_pesa2.py', 'alg30_moma.py']:
    print("=" * 40)
    print("Reading", alg)
    try:
        with open(os.path.join("algorithms", alg)) as f:
            print("\n".join(f.readlines()[:20]))
    except Exception as e:
        print(e)
