"""
alg02_epsilon_constraint.py - Epsilon-Constraint Method
======================================================
Family: Classical (Part 1)

Core Mechanism:
Optimizes one primary objective while bounding all other (M-1) objectives
by upper thresholds (epsilon values):
    min f_1(x)
    subject to f_k(x) <= eps_k,  k = 2, ..., M
    and original problem constraints.
By systematically varying eps_k across the objective range, non-convex and
dented regions of the Pareto front can be reached.

Lecture Steps:
1. Determine the individual minimum and maximum for each objective (payoff table/bounds).
2. Designate one objective as primary (e.g., f_1).
3. Discretize the bounds of secondary objective(s) into a grid of eps values.
4. For each eps vector:
   a. Formulate constrained single-objective sub-problem.
   b. Solve with nonlinear constrained optimizer (e.g., SLSQP).
   c. Record solution.
5. Filter non-dominated solutions.

Default Parameters:
- n_eps: 25
- primary_obj: 0
"""

import numpy as np
from scipy.optimize import minimize
from typing import Tuple, List, Dict, Any, Optional
import moo_utils as mu


def initialize(problem: Any, n_eps: int = 25, primary_obj: int = 0) -> np.ndarray:
    """Computes epsilon grid for secondary objectives."""
    # Find approx range of secondary objectives
    sec_objs = [i for i in range(problem.n_objs) if i != primary_obj]
    # Sample problem to find objective range
    rng = np.random.default_rng(42)
    X_sample = rng.uniform(problem.xl, problem.xu, size=(100, problem.n_vars))
    F_sample = np.array([problem.evaluate(x)[0] for x in X_sample])

    eps_grid = []
    for s in sec_objs:
        f_min = float(np.min(F_sample[:, s]))
        f_max = float(np.max(F_sample[:, s]))
        eps_grid.append(np.linspace(f_min, f_max, n_eps))

    return np.array(eps_grid).T # (n_eps, M-1)


def step(problem: Any, eps_val: float, primary_obj: int = 0,
         x0: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray, float]:
    """Solves one epsilon-constrained subproblem."""
    if x0 is None:
        x0 = 0.5 * (problem.xl + problem.xu)

    bounds = list(zip(problem.xl, problem.xu))
    sec_obj = 1 if primary_obj == 0 else 0

    def objective(x):
        f, cv = problem.evaluate(x)
        return f[primary_obj] + 1e4 * cv

    def constraint_fun(x):
        f, _ = problem.evaluate(x)
        return eps_val - f[sec_obj] # eps_val - f2 >= 0

    res = minimize(
        fun=objective,
        x0=x0,
        bounds=bounds,
        constraints={'type': 'ineq', 'fun': constraint_fun},
        method='SLSQP',
        options={'maxiter': 500, 'ftol': 1e-7}
    )
    x_opt = res.x
    f_opt, cv_opt = problem.evaluate(x_opt)
    # Check if eps constraint is violated
    if f_opt[sec_obj] > eps_val + 1e-4:
        cv_opt += (f_opt[sec_obj] - eps_val)
    return x_opt, f_opt, cv_opt


def run(problem: Any, n_eps: int = 25, seed: int = 42) -> Dict[str, Any]:
    """Runs the full epsilon-constraint sweep."""
    eps_vals = initialize(problem, n_eps=n_eps, primary_obj=0)
    X_res = []
    F_res = []
    CV_res = []

    rng = np.random.default_rng(seed)
    x0 = rng.uniform(problem.xl, problem.xu)

    for eps in eps_vals:
        e = float(np.ravel(eps)[0])
        x_opt, f_opt, cv_opt = step(problem, e, primary_obj=0, x0=x0)
        X_res.append(x_opt)
        F_res.append(f_opt)
        CV_res.append(cv_opt)
        x0 = x_opt

    X_arr = np.array(X_res)
    F_arr = np.array(F_res)
    CV_arr = np.array(CV_res)

    fronts = mu.fast_non_dominated_sort(F_arr, CV_arr)
    nd_indices = fronts[0] if len(fronts) > 0 else []

    return {
        'algorithm': 'Epsilon-Constraint',
        'X_all': X_arr,
        'F_all': F_arr,
        'CV_all': CV_arr,
        'X_front': X_arr[nd_indices],
        'F_front': F_arr[nd_indices],
        'eps_grid': eps_vals,
        'evaluations': n_eps * 150
    }
