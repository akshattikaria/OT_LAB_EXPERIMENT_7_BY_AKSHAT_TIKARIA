"""
alg03_benson.py - Benson's Method
=================================
Family: Classical (Part 1)

Core Mechanism:
Benson's method projects a dominated or reference point u0 onto the Pareto
front by maximizing the distance past the reference point:
    max sum_{m=1}^M w_m * l_m  (or min -sum w_m * l_m)
    subject to:
        f_m(x) + l_m <= u0_m,  for all m = 1, ..., M
        l_m >= 0,  x in Feasible Region.
This guarantees that the resulting point is strictly Pareto-optimal. By varying
the reference point u0 or weights w, different parts of the front are reached.

Lecture Steps:
1. Choose an initial reference point u0 (e.g., nadir or an attainable interior point).
2. Introduce non-negative slack/shortfall variables l = [l_1, ..., l_M].
3. Formulate the single-objective LP/NLP:
       min_{x, l} -sum_{m=1}^M w_m * l_m + penalty * (constraint violations)
       s.t. f_m(x) + l_m <= u0_m, l_m >= 0.
4. Solve sub-problem to obtain efficient solution x*.
5. Sweep u0 across the objective domain to generate the Pareto front.

Default Parameters:
- n_ref_points: 25
- weights: equal weights w_m = 1/M
"""

import numpy as np
from scipy.optimize import minimize
from typing import Tuple, List, Dict, Any, Optional
import moo_utils as mu


def initialize(problem: Any, n_points: int = 25) -> np.ndarray:
    """Generates a sequence of reference points u0 across the problem domain."""
    rng = np.random.default_rng(42)
    X_sample = rng.uniform(problem.xl, problem.xu, size=(100, problem.n_vars))
    F_sample = np.array([problem.evaluate(x)[0] for x in X_sample])

    f_min = np.min(F_sample, axis=0)
    f_max = np.max(F_sample, axis=0)

    # Reference points spanning between ideal and nadir
    alphas = np.linspace(0.1, 1.2, n_points)
    u0_list = [f_min + a * (f_max - f_min) for a in alphas]
    return np.array(u0_list)


def step(problem: Any, u0: np.ndarray, weights: Optional[np.ndarray] = None,
         x0: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray, float]:
    """Solves one Benson projection subproblem."""
    M = problem.n_objs
    if weights is None:
        weights = np.ones(M) / M

    if x0 is None:
        x0 = 0.5 * (problem.xl + problem.xu)

    bounds = list(zip(problem.xl, problem.xu))

    # Formulate penalized objective: minimize f past u0
    def benson_obj(x):
        f, cv = problem.evaluate(x)
        # distance/shortfall past u0: shortfall = max(0, u0 - f)
        # We want to minimize f while staying <= u0
        shortfall = np.maximum(0.0, u0 - f)
        violation = np.maximum(0.0, f - u0)
        # Maximize shortfall <=> minimize -sum(w * shortfall)
        return float(-np.dot(weights, shortfall) + 1e3 * np.sum(violation) + 1e4 * cv)

    res = minimize(
        fun=benson_obj,
        x0=x0,
        bounds=bounds,
        method='SLSQP',
        options={'maxiter': 500, 'ftol': 1e-7}
    )
    x_opt = res.x
    f_opt, cv_opt = problem.evaluate(x_opt)
    return x_opt, f_opt, cv_opt


def run(problem: Any, n_points: int = 25, seed: int = 42) -> Dict[str, Any]:
    """Runs Benson's method across multiple reference targets."""
    u0_grid = initialize(problem, n_points=n_points)
    X_res = []
    F_res = []
    CV_res = []

    rng = np.random.default_rng(seed)
    x0 = rng.uniform(problem.xl, problem.xu)

    for u0 in u0_grid:
        x_opt, f_opt, cv_opt = step(problem, u0, x0=x0)
        X_res.append(x_opt)
        F_res.append(f_opt)
        CV_res.append(cv_opt)
        x0 = x_opt

    X_arr = np.array(X_res)
    F_arr = np.array(F_res)
    CV_arr = np.array(CV_res)

    fronts = mu.fast_non_dominated_sort(F_arr, CV_arr)
    nd_indices = fronts[0] if len(fronts) > 0 else []

    return {
        'algorithm': "Benson's Method",
        'X_all': X_arr,
        'F_all': F_arr,
        'CV_all': CV_arr,
        'X_front': X_arr[nd_indices],
        'F_front': F_arr[nd_indices],
        'ref_points': u0_grid,
        'evaluations': n_points * 150
    }
