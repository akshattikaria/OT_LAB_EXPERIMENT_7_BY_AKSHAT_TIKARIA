import numpy as np
import moo_utils

# Test 1: normalize_objectives with min/max of itself
front = np.array([[0, 1], [0.5, 0.5], [1, 0]])
norm_f, ideal, nadir = moo_utils.normalize_objectives(front)
print("Self-norm F:\n", norm_f)

# The goal for compute_metrics is to use fixed per-problem ideal/nadir
# P3 true front
p3 = moo_utils.ProblemP3()
tf = p3.true_pareto_front(500)
hv, igd, sp = moo_utils.compute_metrics(tf, 'P3')
print("P3 TF HV:", hv, "IGD:", igd)

# Single point on P3
pt = np.array([[0.0, 1.0]])
hv_pt, igd_pt, sp_pt = moo_utils.compute_metrics(pt, 'P3')
print("P3 pt HV:", hv_pt, "IGD:", igd_pt)

