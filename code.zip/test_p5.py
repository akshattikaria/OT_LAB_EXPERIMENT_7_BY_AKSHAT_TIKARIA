import numpy as np
from moo_utils import ProblemP5

def test_p5_front():
    p5 = ProblemP5()
    tf = p5.true_pareto_front(500)
    print("TF shape:", tf.shape)
    print("Min f1:", np.min(tf[:, 0]))
    print("Max f1:", np.max(tf[:, 0]))
    print("Min f2:", np.min(tf[:, 1]))
    print("Max f2:", np.max(tf[:, 1]))

test_p5_front()
