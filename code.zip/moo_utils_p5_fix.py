import numpy as np

def true_pareto_front(n_points: int = 100) -> np.ndarray:
    xl = np.array([0.01, 0.02]) # b, h
    xu = np.array([0.10, 0.20])
    L = 1.0
    P = 1000.0
    E = 200e9
    rho = 7850.0
    bh2_min = 2.4e-5 
    
    # Pareto front occurs along b * h^2 = 2.4e-5? Let's check.
    # No, as we saw h=0.20 and b=0.01 is feasible (0.01 * 0.04 = 0.0004 >= 2.4e-5)
    # Actually, as h increases, f1=rho*L*b*h increases, f2=.../bh^3 decreases.
    # If we fix h, to minimize f1 and f2 we want b as small as possible.
    # So b = max(xl[0], bh2_min / h^2).
    # Since xl[0] = 0.01 and bh2_min = 2.4e-5, bh2_min / h^2 is:
    # at h=0.02: 2.4e-5 / 0.0004 = 0.06 (which is > 0.01)
    # at h=0.20: 2.4e-5 / 0.04 = 0.0006 (which is < 0.01)
    
    # So the front has two parts:
    # 1. b is constrained by the stress constraint: b = 2.4e-5 / h^2
    #    This holds when 2.4e-5 / h^2 >= 0.01 => h <= sqrt(0.0024) ~ 0.048989
    # 2. b is constrained by its lower bound: b = 0.01
    #    This holds when h > sqrt(0.0024)
    
    h_vals = np.linspace(xl[1], xu[1], n_points)
    b_vals = np.maximum(xl[0], bh2_min / (h_vals ** 2))
    
    f1 = rho * L * b_vals * h_vals
    f2 = (4.0 * P * (L ** 3)) / (E * b_vals * (h_vals ** 3))
    
    # Note that there is another bound: h cannot exceed 0.20.
    
    return np.column_stack([f1, f2])

print(true_pareto_front(10))
