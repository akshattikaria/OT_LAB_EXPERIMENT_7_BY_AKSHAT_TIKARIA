import numpy as np
import matplotlib.pyplot as plt

def true_pareto_front(n_points: int = 100) -> np.ndarray:
    xl = np.array([0.01, 0.02])
    xu = np.array([0.10, 0.20])
    L = 1.0
    P = 1000.0
    E = 200e9
    rho = 7850.0
    bh2_min = 2.4e-5
    
    h_vals = np.linspace(xl[1], xu[1], n_points)
    b_vals = np.maximum(xl[0], bh2_min / (h_vals ** 2))
    
    f1 = rho * L * b_vals * h_vals
    f2 = (4.0 * P * (L ** 3)) / (E * b_vals * (h_vals ** 3))
    
    return np.column_stack([f1, f2])

tf = true_pareto_front(500)
# check if non-dominated
from moo_utils import fast_non_dominated_sort
fronts = fast_non_dominated_sort(tf)
print("Front 0 length:", len(fronts[0]), "Total length:", len(tf))
