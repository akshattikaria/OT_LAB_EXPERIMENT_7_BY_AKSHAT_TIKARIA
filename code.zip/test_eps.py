import moo_utils
from algorithms import alg02_epsilon_constraint as alg02

p = moo_utils.ProblemP3()
# It seems alg02 is ALREADY using payoff bounds because the front size is 25 and points are good.
# Let's check alg02_epsilon_constraint.py
