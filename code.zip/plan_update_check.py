# The S3 algorithm modifications seem to be ALREADY IMPLEMENTED mostly?!
# Wait, let me check alg29_moba.py explicitly to see if it has the bug
with open("algorithms/alg29_moba.py") as f:
    text = f.read()
    if "current_iter = it + 1" in text:
        print("MOBA already has current_iter = it + 1")
    else:
        print("MOBA needs fix")
