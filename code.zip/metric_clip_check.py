import numpy as np
from moo_utils import compute_metrics, ProblemP3

pt = np.array([[0, 2.0]]) # Very bad point, F_norm will be [0, 2]
hv, igd, sp = compute_metrics(pt, 'P3')
print("HV:", hv, "IGD:", igd)
