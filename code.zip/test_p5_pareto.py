import numpy as np
from moo_utils import ProblemP5

def analyze_p5_pareto():
    p5 = ProblemP5()
    
    # Grid search to find true pareto front empirically
    b_vals = np.linspace(p5.xl[0], p5.xu[0], 200)
    h_vals = np.linspace(p5.xl[1], p5.xu[1], 200)
    
    B, H = np.meshgrid(b_vals, h_vals)
    B = B.flatten()
    H = H.flatten()
    
    f1 = p5.rho * p5.L * B * H
    f2 = (4.0 * p5.P * (p5.L ** 3)) / (p5.E * B * (H ** 3))
    
    cv = np.maximum(0.0, (p5.bh2_min - B * H**2) / p5.bh2_min)
    valid = cv <= 1e-9
    
    f1_valid = f1[valid]
    f2_valid = f2[valid]
    
    points = np.column_stack((f1_valid, f2_valid))
    
    from moo_utils import fast_non_dominated_sort
    fronts = fast_non_dominated_sort(points)
    
    pareto_front = points[fronts[0]]
    pareto_front = pareto_front[np.argsort(pareto_front[:, 0])]
    
    print("Empirical Pareto Front:")
    print("Min f1:", np.min(pareto_front[:, 0]))
    print("Max f1:", np.max(pareto_front[:, 0]))
    print("Min f2:", np.min(pareto_front[:, 1]))
    print("Max f2:", np.max(pareto_front[:, 1]))

    
    import matplotlib.pyplot as plt
    plt.figure()
    plt.scatter(f1_valid, f2_valid, s=1, color='lightgray', label='Feasible')
    plt.scatter(pareto_front[:, 0], pareto_front[:, 1], s=5, color='red', label='Empirical PF')
    
    tf = p5.true_pareto_front(100)
    plt.plot(tf[:, 0], tf[:, 1], color='blue', label='Current true_pareto_front')
    plt.legend()
    plt.savefig('p5_front.png')
    
analyze_p5_pareto()
