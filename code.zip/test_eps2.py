import moo_utils
from algorithms import alg03_benson as alg03

p = moo_utils.ProblemP1()
res = alg03.run(p)
f = res['F_front']
print('front size:', len(f))
