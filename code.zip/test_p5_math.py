import numpy as np

def true_pareto_front(n_points: int = 100) -> np.ndarray:
    xl = np.array([0.01, 0.02])
    xu = np.array([0.10, 0.20])
    L = 1.0
    P = 1000.0
    E = 200e9
    rho = 7850.0
    bh2_min = 2.4e-5
    
    h_min = np.sqrt(bh2_min / xl[0])
    h_min = max(h_min, xl[1])
    h_vals = np.linspace(h_min, xu[1], n_points)
    b_vals = np.full(n_points, xl[0])
    
    f1 = rho * L * b_vals * h_vals
    f2 = (4.0 * P * (L ** 3)) / (E * b_vals * (h_vals ** 3))
    
    return np.column_stack([f1, f2])

tf = true_pareto_front(100)
print("Min f1:", np.min(tf[:,0]))
print("Max f1:", np.max(tf[:,0]))
print("Min f2:", np.min(tf[:,1]))
print("Max f2:", np.max(tf[:,1]))

from moo_utils import ProblemP5
p5 = ProblemP5()
b_rand = np.random.uniform(p5.xl[0], p5.xu[0], 1000000)
h_rand = np.random.uniform(p5.xl[1], p5.xu[1], 1000000)
f1_rand = p5.rho * p5.L * b_rand * h_rand
f2_rand = (4.0 * p5.P * (p5.L ** 3)) / (p5.E * b_rand * (h_rand ** 3))
cv = np.maximum(0.0, (p5.bh2_min - b_rand * h_rand**2) / p5.bh2_min)
valid = cv <= 1e-9

f1_valid = f1_rand[valid]
f2_valid = f2_rand[valid]
print("Valid min f1:", np.min(f1_valid))
print("Valid min f2:", np.min(f2_valid))
