import numpy as np
from moo_utils import ProblemP5

p5 = ProblemP5()

# Generate random points
rng = np.random.default_rng(42)
b_rand = rng.uniform(p5.xl[0], p5.xu[0], 100000)
h_rand = rng.uniform(p5.xl[1], p5.xu[1], 100000)

f1_rand = p5.rho * p5.L * b_rand * h_rand
f2_rand = (4.0 * p5.P * (p5.L ** 3)) / (p5.E * b_rand * (h_rand ** 3))

# Check constraint
cv = np.maximum(0.0, (p5.bh2_min - b_rand * h_rand**2) / p5.bh2_min)
valid = cv <= 1e-9

f1_valid = f1_rand[valid]
f2_valid = f2_rand[valid]

print("Valid points min f1:", np.min(f1_valid))
print("Valid points min f2:", np.min(f2_valid))

# The current true_pareto_front in P5
tf_current = p5.true_pareto_front(100)
print("Current TF min f1:", np.min(tf_current[:, 0]))
print("Current TF min f2:", np.min(tf_current[:, 1]))

# Are there valid points that dominate the current TF?
# Let's take the first point of tf_current
p_tf = tf_current[-1]
doms = (f1_valid <= p_tf[0]) & (f2_valid <= p_tf[1]) & ((f1_valid < p_tf[0]) | (f2_valid < p_tf[1]))
print("Number of valid points dominating tf_current[-1]:", np.sum(doms))

# Now check h=0.20
b_opt = np.linspace(p5.xl[0], p5.xu[0], 100)
h_opt = np.full(100, p5.xu[1])
f1_opt = p5.rho * p5.L * b_opt * h_opt
f2_opt = (4.0 * p5.P * (p5.L ** 3)) / (p5.E * b_opt * (h_opt ** 3))

print("h=0.20 min f1:", np.min(f1_opt))
print("h=0.20 min f2:", np.min(f2_opt))

