import moo_utils
p5 = moo_utils.ProblemP5()
tf = p5.true_pareto_front(100)
print(tf.shape)
import numpy as np
print("Min/Max f1:", np.min(tf[:,0]), np.max(tf[:,0]))
print("Min/Max f2:", np.min(tf[:,1]), np.max(tf[:,1]))
