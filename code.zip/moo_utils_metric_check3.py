with open("algorithms/alg02_epsilon_constraint.py") as f:
    text = f.read()
    if "eps in [f2 at f2-minimizer, f2 at lexicographic f1-minimizer]" in text:
        print("alg02 comment found")
