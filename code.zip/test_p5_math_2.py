import numpy as np

p5_xl = np.array([0.01, 0.02])
p5_xu = np.array([0.10, 0.20])
L = 1.0
P = 1000.0
E = 200e9
rho = 7850.0
bh2_min = 2.4e-5

# f1 = rho * L * b * h
# f2 = (4 * P * L^3) / (E * b * h^3)

# To minimize f1 and f2 simultaneously:
# Since f1 is proportional to b*h, and f2 is proportional to 1/(b*h^3).
# If we fix h, f1 is proportional to b, and f2 is proportional to 1/b.
# So decreasing b decreases f1 but increases f2. 
# BUT wait: f1*f2 = (rho*L * 4*P*L^3) / (E * h^2)
# If we fix f1, to minimize f2 we need to maximize h. So b should be as small as possible.
# Hence, the Pareto front occurs at the minimum possible b for a given h, 
# or the maximum possible h for a given f1?
# Let's say we set b to its lower bound xl[0] = 0.01.
# Then b*h^2 >= 2.4e-5 implies h >= sqrt(2.4e-3) = 0.04898979.
# For any given point (b, h) on the PF, could we decrease b and increase h to keep f1 constant?
# If we keep b*h = C constant, then f2 is proportional to 1/(C*h^2).
# So to minimize f2 for a given f1, we should make h as LARGE as possible, which means making b as SMALL as possible.
# Thus, on the Pareto front, b should always be at its absolute minimum possible value, which is xl[0] = 0.01!
# EXCEPT when h hits its upper bound xu[1] = 0.20!
# If h = 0.20, then we can increase b from 0.01 to 0.10. 
# But wait, increasing b increases f1 and decreases f2. So the front is parameterized by b when h is fixed at its upper bound?
# Let's check:
# Curve 1: b = 0.01, h ranges from sqrt(0.0024) to 0.20.
# f1 increases with h, f2 decreases with h. This IS a Pareto front!
# Curve 2: h = 0.20, b ranges from 0.01 to 0.10.
# f1 increases with b, f2 decreases with b. This IS ALSO a Pareto front!

def true_pareto_front(n_points: int = 100) -> np.ndarray:
    n1 = n_points // 2
    n2 = n_points - n1
    
    h_min = max(0.02, np.sqrt(2.4e-5 / 0.01))
    
    # Curve 1: b = 0.01, h in [h_min, 0.20]
    h1 = np.linspace(h_min, 0.20, n1)
    b1 = np.full(n1, 0.01)
    
    # Curve 2: h = 0.20, b in [0.01, 0.10]
    b2 = np.linspace(0.01, 0.10, n2)
    h2 = np.full(n2, 0.20)
    
    b_vals = np.concatenate([b1, b2])
    h_vals = np.concatenate([h1, h2])
    
    f1 = rho * L * b_vals * h_vals
    f2 = (4.0 * P * (L ** 3)) / (E * b_vals * (h_vals ** 3))
    
    points = np.column_stack([f1, f2])
    # remove duplicate if any, or just return
    # sorting by f1
    points = points[np.argsort(points[:, 0])]
    from moo_utils import fast_non_dominated_sort
    fronts = fast_non_dominated_sort(points)
    nd = points[fronts[0]]
    nd = nd[np.argsort(nd[:, 0])]
    return nd

tf = true_pareto_front(100)
print(np.min(tf, axis=0))
print(np.max(tf, axis=0))

